﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Crosshelper.Views
{
    public partial class NewcomersSettingPage : ContentPage
    {
        public NewcomersSettingPage()
        {
            InitializeComponent();
        }
    }
}
