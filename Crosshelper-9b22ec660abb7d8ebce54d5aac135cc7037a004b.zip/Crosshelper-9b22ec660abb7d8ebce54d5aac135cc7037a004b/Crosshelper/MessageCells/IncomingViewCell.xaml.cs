﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Crosshelper.MessageCells
{
    public partial class IncomingViewCell : ViewCell
    {
        public IncomingViewCell()
        {
            InitializeComponent();
        }
    }
}
