﻿using System;
namespace Crosshelper.Models
{
    public class ReviewLabelContent
    {
        public ReviewLabelContent()
        {
        }
        public string ReviewerName { get; set; }
        public string ReviewerRating { get; set; }
        public string ReviewerContent { get; set; }
    }
}
