﻿using System;
namespace Crosshelper.Models
{
    public class TypeProblem
    {
        public int TagID { get; set; }
        public string Pcategory { get; set; }
        public string ImageUrl { get; set; }
    }
}
