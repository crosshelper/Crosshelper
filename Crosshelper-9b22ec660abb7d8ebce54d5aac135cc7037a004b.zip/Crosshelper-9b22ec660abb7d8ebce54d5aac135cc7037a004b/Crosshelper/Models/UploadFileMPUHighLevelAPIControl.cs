﻿using Amazon.S3;
using Amazon.S3.Transfer;
using System;
using System.IO;
using System.Threading.Tasks;
namespace Crosshelper.Models
{
    public class UploadFileMPUHighLevelAPIControl
    {
        public UploadFileMPUHighLevelAPIControl()
        {
        }
    }
}
