﻿namespace Crosshelper.Models
{
    public class ReviewsInfo
    {
        public string ReviewID { get; set; }
        public string UserID { get; set; }
        public int ReviewRating { get; set; }
        public string ReviewContent { get; set; }
    }
}
