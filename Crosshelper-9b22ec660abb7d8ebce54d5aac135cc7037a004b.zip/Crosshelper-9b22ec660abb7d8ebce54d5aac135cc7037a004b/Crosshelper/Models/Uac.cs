﻿namespace Crosshelper.Models
{
    public class Uac
    {
        public string UserID { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string Pwd { get; set; }
    }
}
