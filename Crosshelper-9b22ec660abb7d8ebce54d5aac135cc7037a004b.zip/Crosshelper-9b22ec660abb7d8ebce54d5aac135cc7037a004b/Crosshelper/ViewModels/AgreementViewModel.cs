﻿using System;
namespace Crosshelper.ViewModels
{
    public class AgreementViewModel
    {
        public AgreementViewModel()
        {
        }
    }
}
